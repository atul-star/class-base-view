
from fbv.models import Product

def check_product(fun):
    def inner(prod):
        if type(prod)==Product:
            errors = {}
            if type(prod.qty)!=int or prod.qty<=0:
                    errors['QTY'] = 'INVALID QTY'
            if type(prod.price) != float  or prod.price <=2000:
                    errors['PRICE'] = 'INVALID PRICE'
            if type(prod.id) != int  or prod.id <= 0:
                    errors['ID'] = 'INVALID ID'

            if errors:
                for key,value in errors.items():
                    print(key, ": ",value)
                return errors
            else:
                return fun(prod)


    return inner


@check_product
def check_for_valid_product(prod):
    return True


class ProductServiceImpl:

    @staticmethod
    def add_product(product):
        noerrors =check_for_valid_product(product)
        if noerrors==True:
            dbprod = ProductServiceImpl.get_product(product.id)
            product.save()
            if dbprod:
                return "Product Updated...!"
            else:
                return "Product Added"
        else:
            return noerrors

    @staticmethod
    def get_product(prodid):
        dbprods = Product.objects.filter(id=prodid,active='Y')
        if dbprods:
            return dbprods[0]

    @staticmethod
    def delete_product(prodid):
        dbprods = Product.objects.filter(id=prodid,active='Y')
        if dbprods:
            dbprods[0].active='N'
            dbprods[0].save()
            return "Product Removed..!"
        else:
            return "No Product Avlb with Given Identifier..!"

    @staticmethod
    def get_all_product():
        return Product.objects.all().filter(active='Y')

    @staticmethod
    def dummy_product():
        return Product(id=0,name='',price=0.0,qty=0,code='',spec='')