from django.db import models

# Create your models here.
class Product(models.Model):
    name=models.CharField('prod_name',max_length=100)
    spec=models.TextField('prod_spct',max_length=100)
    qty = models.IntegerField('prod_qty')
    price = models.FloatField('prod_price')
    code = models.CharField('prod_bar',max_length=100)
    active = models.CharField('active',max_length=10, default='Y')

