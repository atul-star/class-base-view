from django.apps import AppConfig


class FbvConfig(AppConfig):
    name = 'fbv'
