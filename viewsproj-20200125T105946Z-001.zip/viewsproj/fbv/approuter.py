
from django.urls import path
from fbv.views import ProductOps
from django.conf.urls import url
urlpatterns = [
    url(r'^products/',ProductOps.as_view(),name="prod_ops"),
]
