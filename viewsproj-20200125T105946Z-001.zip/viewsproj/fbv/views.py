from django.shortcuts import render
from fbv.productservices import ProductServiceImpl as service
from fbv.models import Product

def give_me_context_data(msg=None,pid=None):
    prod = service.dummy_product()
    if pid:
        prod=service.get_product(pid)
    return {
        "prod": prod,
        "products": service.get_all_product(),
        "actionmsg" : msg
    }

from django.views.generic import View
class ProductOps(View):
    def get(self,req):
        print('inside cbv--get',req.POST,req.build_absolute_uri())
        try:
            if req.build_absolute_uri().split('/')[-2]=="delete":
                service.delete_product(int(req.build_absolute_uri().split('/')[-1]))
            elif req.build_absolute_uri().split('/')[-2] == "edit":
                return render(req, 'product.html', give_me_context_data(pid=int(req.build_absolute_uri().split('/')[-1])))
        except:
            pass
        return render(req,'product.html',give_me_context_data())
    def post(self,req):
        prodinfo = req.POST
        print('inside cbv--POST', req.POST, req.build_absolute_uri())
        #print(prodinfo)
        try:
            if req.build_absolute_uri().split('/')[-2]=="delete":
                service.delete_product(int(req.build_absolute_uri().split('/')[-1]))
            elif req.build_absolute_uri().split('/')[-2] == "edit":
                service.get_product(int(req.build_absolute_uri().split('/')[-1]))

        except:

            pass
        return render(req,'product.html',give_me_context_data(
            service.add_product(Product(id=int(prodinfo['pid']),name=prodinfo['pnm'],
                       price=float(prodinfo['pprice']),qty=int(prodinfo['pqty']),
                       code=prodinfo['pcode'],spec=prodinfo['pspec']))))



#def fetch_for_update(req,pid):
#    return render(req,'product.html',give_me_context_data(pid=pid))

#def delete_product_info(req,pid):
#    msg = service.delete_product(pid)
#    return render(req,'product.html',give_me_context_data(msg))