from django.apps import AppConfig


class DtvConfig(AppConfig):
    name = 'dtv'
