
from django.urls import path
from fbv.views import welcome_product_page,save_product_info,fetch_for_update,delete_product_info
urlpatterns = [
    path('welcome/',welcome_product_page),
    path('save/',save_product_info),
    path('edit/<int:pid>',fetch_for_update),
    path('delete/<int:pid>',delete_product_info),
]
