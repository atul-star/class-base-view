from django.shortcuts import render
from fbv.productservices import ProductServiceImpl as service
from fbv.models import Product

def give_me_context_data(msg=None,pid=None):
    prod = service.dummy_product()
    if pid:
        prod=service.get_product(pid)
    return {
        "prod": prod,
        "products": service.get_all_product(),
        "actionmsg" : msg
    }

def welcome_product_page(req):
    return render(req,'product.html',give_me_context_data())

def save_product_info(req):
    prodinfo = req.POST
    #print(prodinfo)
    return render(req,'product.html',give_me_context_data(
        service.add_product(Product(id=int(prodinfo['pid']),name=prodinfo['pnm'],
                   price=float(prodinfo['pprice']),qty=int(prodinfo['pqty']),
                   code=prodinfo['pcode'],spec=prodinfo['pspec']))))

def fetch_for_update(req,pid):
    return render(req,'product.html',give_me_context_data(pid=pid))

def delete_product_info(req,pid):
    msg = service.delete_product(pid)
    return render(req,'product.html',give_me_context_data(msg))