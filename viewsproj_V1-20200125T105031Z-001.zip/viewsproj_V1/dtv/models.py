from django.db import models

# Create your models here.
class Product(models.Model):
    name=models.CharField('prod_name',max_length=100)
    spec=models.CharField('prod_spct',max_length=100)
    quantity = models.IntegerField('prod_qty')
    price = models.FloatField('prod_price')
    barcode = models.EmailField('prod_bar',max_length=100,validators=[checkclcemail])
    active = models.CharField('active',max_length=10, default='Y')

