from django.shortcuts import render
from django.views.generic import View
from fbv.productservices import ProductServiceImpl as service
from fbv.models import Product
from fbv.views import give_me_context_data

class ProductOps(View):

    def get(self,req):
        return render(req,'prod.html',give_me_context_data())

    def post(self,req):
        prodinfo = req.POST
        return render(req, 'product.html', give_me_context_data(
            service.add_product(Product(id=int(prodinfo['pid']), name=prodinfo['pnm'],
                                        price=float(prodinfo['pprice']), qty=int(prodinfo['pqty']),
                                        code=prodinfo['pcode'], spec=prodinfo['pspec']))))
